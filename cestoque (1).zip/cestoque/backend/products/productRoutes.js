const express = require('express');
const router = express.Router();
const Product = require('./productSchema');


// Rota para adicionar um produto
router.post('/', async (req, res) => {
    const product = new Product(req.body);
    await product.save();
    res.status(201).send(product);
});

// Rota para editar um produto
router.put('/:id', async (req, res) => {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.send(product);
});

// Rota para excluir um produto
router.delete('/:id', async (req, res) => {
    const product = await Product.findByIdAndDelete(req.params.id);
    res.send(product);
});

// Rota para obter todos os produtos
router.get('/', async (req, res) => {
    const products = await Product.find();
    res.send(products);
});

module.exports = router;